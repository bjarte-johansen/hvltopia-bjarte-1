export const MediaSyntaxOptions = {
    queryInParens: true
};

export const ContainerSyntaxOptions = {
    queryInParens: true
};
